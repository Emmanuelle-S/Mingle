const ServiceManager = require("../models/");

class ServiceController {
  async createService(req, res) {
    try {
      const service = await ServiceManager.insert(req.body);
      res.status(201).json(service);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  async getServiceById(req, res) {
    try {
      const service = await ServiceManager.find(req.params.id);
      if (!service) {
        return res.status(404).json({ error: 'Service not found' });
      }
      res.status(200).json(service);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  async getAllServices(req, res) {
    try {
      const services = await ServiceManager.findAll();
      res.status(200).json(services);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  async updateService(req, res) {
    try {
      const service = await ServiceManager.update(req.body);
      res.status(200).json(service);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  async deleteService(req, res) {
    try {
      await ServiceManager.delete(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }
}

module.exports = new ServiceController();
